"""Views, one for each Insta485 page."""
from insta485.views.index import show_index
from insta485.views.index import users
from insta485.views.index import download_file
from insta485.views.index import followers
from insta485.views.index import show_post
from insta485.views.index import following_user
from insta485.views.index import explore
from insta485.views.index import login
from insta485.views.index import logout
from insta485.views.index import password_user

from insta485.views.index import create
from insta485.views.index import delete
from insta485.views.index import edit
from insta485.views.index import auth
from insta485.views.index import show_likes
from insta485.views.index import show_comments
from insta485.views.index import show_posts
from insta485.views.index import show_following
from insta485.views.index import accounts_post
